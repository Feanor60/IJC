/*eratosthenes.h
 * @Řešení IJC-DU1, příklad a), 19.3.2020
 * @Autor: Vojtěch Bůbela
 * @Fakulta: VUT FIT
 * @přeloženo gcc 9.2.1
 */

#include "bitset.h"

void Eratosthenes(bitset_t pole);